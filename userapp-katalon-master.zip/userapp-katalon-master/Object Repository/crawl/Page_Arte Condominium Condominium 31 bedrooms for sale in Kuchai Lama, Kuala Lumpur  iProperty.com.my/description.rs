<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>description</name>
   <tag></tag>
   <elementGuidId>ce32db01-151e-4201-a2d5-8a5520ea3cc9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div/pre</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>pre.ListingDetailstyle__FormattedContentWrapper-rldbg.hwCmrv.property-description</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>pre</value>
      <webElementGuid>5474351f-ca37-4b53-8c50-1dff70b71848</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListingDetailstyle__FormattedContentWrapper-rldbg hwCmrv property-description</value>
      <webElementGuid>211777bb-1f79-434e-a97d-21525f9d5970</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Arte Kuchai Lama For SALE / RENT !!!

Property Details
Name: Arte (also known as Arte @ Kuchai Lama)
Address: Jalan 1/116C, Kuchai Entrepreneurs Park, Kuala Lumpur
Developer: Nusmetro Group
Completion Date: July 2015 
Type: Condominium
Tenure: Leasehold
No. of Blocks: 2
No. of Storey: 22
No. of Units: 254
No. of Bedrooms: 3
No. of Bathrooms: 3 - 4

Built-up
Type A(a): 2,045 sf
Type B(a): 1,948 sf
Type C(a): 1,496 sf
Type C(b): 1,421 sf
Type D(b): 1,711 sf
Type E(a): 1,733 sf

Facilities
Entrance lobby
Car park lots
Unsymmetrical landscaped garden
BBQ area
Futuristic lounge area
Swimming pool
Jacuzzi
Gourmet pavilion
Gymnasium
24 hours security

Arte is just a mere eight kilometers away from the KL City Centre. It is also connected via quite a few major highways such as the New Pantai Expressway (NPE), North - South Highway, Shah Alam KESAS Highway, Middle Ring Road 2, Federal Highway, Jalan Klang Lama, Sungai Besi Highway and KL - Putrajaya MEX Highway.

Call For More Details:
Chris Lee 012-332 7787

***WELCOME OWNER TO LIST***
Dear Owner, 
If you have any property 
(Residential / Commercial/ Factories/ Land) 
that you would like to engage with our service to Sell/Rent
Kindly contact me as below:
Call/SMS/Whatsapp: Chris Lee 012-332 7787
E-Mail: chrisleemk23@gmail.com</value>
      <webElementGuid>88e04ec2-1e7d-4691-8748-6533eaf963f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;DetailContainerstyle__DetailWrapper-gOTxDn fJCHkB&quot;]/div[@class=&quot;ListingDetailstyle__Detail-leUXpB davqsX&quot;]/div[@class=&quot;ListingDetailstyle__MainContainer-fckUjw dsRKkO&quot;]/div[@class=&quot;ListingDetailstyle__LeftContainerWrapper-kzCUBn dYqgCF&quot;]/div[@class=&quot;ListingDetailstyle__PropertyInfo-nYNvB hfNcQw&quot;]/div[@class=&quot;ListingDetailstyle__MainContentContainer-groYjV dMOnQB&quot;]/div[@class=&quot;ListingDetailstyle__ComponentContainer-fintGE ListingDescriptionstyle__DescriptionContainer-gfGIhK bHABqv IJTWd listing-description&quot;]/div[@class=&quot;ShowMorestyle__ShowMoreContainer-jHAKYk fXRCEn&quot;]/div[@class=&quot;container&quot;]/pre[@class=&quot;ListingDetailstyle__FormattedContentWrapper-rldbg hwCmrv property-description&quot;]</value>
      <webElementGuid>acd92a50-02db-436a-af66-a09e36d3c33a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div/pre</value>
      <webElementGuid>2beaeb02-4b1f-4192-a806-af218c327510</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Arte Condominium, Kuchai Lama'])[2]/following::pre[1]</value>
      <webElementGuid>a94b341e-08a3-441f-b6ea-5724cf66990e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read more'])[1]/following::pre[1]</value>
      <webElementGuid>88d98aca-2ae1-4c23-83f4-c10227e5283a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Show less'])[1]/preceding::pre[1]</value>
      <webElementGuid>bf5b7baa-6faf-4a01-a9ea-6976543e69c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Property Details'])[1]/preceding::pre[1]</value>
      <webElementGuid>8648c925-b5ed-4c02-b006-65adb41d27cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//pre</value>
      <webElementGuid>0831ca53-7edb-47a1-8463-47b96baa85fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//pre[(text() = 'Arte Kuchai Lama For SALE / RENT !!!

Property Details
Name: Arte (also known as Arte @ Kuchai Lama)
Address: Jalan 1/116C, Kuchai Entrepreneurs Park, Kuala Lumpur
Developer: Nusmetro Group
Completion Date: July 2015 
Type: Condominium
Tenure: Leasehold
No. of Blocks: 2
No. of Storey: 22
No. of Units: 254
No. of Bedrooms: 3
No. of Bathrooms: 3 - 4

Built-up
Type A(a): 2,045 sf
Type B(a): 1,948 sf
Type C(a): 1,496 sf
Type C(b): 1,421 sf
Type D(b): 1,711 sf
Type E(a): 1,733 sf

Facilities
Entrance lobby
Car park lots
Unsymmetrical landscaped garden
BBQ area
Futuristic lounge area
Swimming pool
Jacuzzi
Gourmet pavilion
Gymnasium
24 hours security

Arte is just a mere eight kilometers away from the KL City Centre. It is also connected via quite a few major highways such as the New Pantai Expressway (NPE), North - South Highway, Shah Alam KESAS Highway, Middle Ring Road 2, Federal Highway, Jalan Klang Lama, Sungai Besi Highway and KL - Putrajaya MEX Highway.

Call For More Details:
Chris Lee 012-332 7787

***WELCOME OWNER TO LIST***
Dear Owner, 
If you have any property 
(Residential / Commercial/ Factories/ Land) 
that you would like to engage with our service to Sell/Rent
Kindly contact me as below:
Call/SMS/Whatsapp: Chris Lee 012-332 7787
E-Mail: chrisleemk23@gmail.com' or . = 'Arte Kuchai Lama For SALE / RENT !!!

Property Details
Name: Arte (also known as Arte @ Kuchai Lama)
Address: Jalan 1/116C, Kuchai Entrepreneurs Park, Kuala Lumpur
Developer: Nusmetro Group
Completion Date: July 2015 
Type: Condominium
Tenure: Leasehold
No. of Blocks: 2
No. of Storey: 22
No. of Units: 254
No. of Bedrooms: 3
No. of Bathrooms: 3 - 4

Built-up
Type A(a): 2,045 sf
Type B(a): 1,948 sf
Type C(a): 1,496 sf
Type C(b): 1,421 sf
Type D(b): 1,711 sf
Type E(a): 1,733 sf

Facilities
Entrance lobby
Car park lots
Unsymmetrical landscaped garden
BBQ area
Futuristic lounge area
Swimming pool
Jacuzzi
Gourmet pavilion
Gymnasium
24 hours security

Arte is just a mere eight kilometers away from the KL City Centre. It is also connected via quite a few major highways such as the New Pantai Expressway (NPE), North - South Highway, Shah Alam KESAS Highway, Middle Ring Road 2, Federal Highway, Jalan Klang Lama, Sungai Besi Highway and KL - Putrajaya MEX Highway.

Call For More Details:
Chris Lee 012-332 7787

***WELCOME OWNER TO LIST***
Dear Owner, 
If you have any property 
(Residential / Commercial/ Factories/ Land) 
that you would like to engage with our service to Sell/Rent
Kindly contact me as below:
Call/SMS/Whatsapp: Chris Lee 012-332 7787
E-Mail: chrisleemk23@gmail.com')]</value>
      <webElementGuid>c17e4aa7-4d19-46f4-9e28-1d1a77910c80</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
