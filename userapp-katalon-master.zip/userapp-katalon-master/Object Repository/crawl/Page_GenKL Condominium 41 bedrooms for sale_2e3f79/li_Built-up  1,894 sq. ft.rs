<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Built-up  1,894 sq. ft</name>
   <tag></tag>
   <elementGuidId>1506d062-8aeb-437c-abf7-1c2260d4a5b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[2]/div[2]/div/div/div/div[3]/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.PropertySummarystyle__AreaInfoItem-NjZCY.dUovgc</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>57291d06-9b7d-4440-b28c-efd310177fb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>PropertySummarystyle__AreaInfoItem-NjZCY dUovgc</value>
      <webElementGuid>b4b7e033-3d12-4c66-a02f-f9ba836bd16d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Built-up : 1,894 sq. ft.</value>
      <webElementGuid>7e502add-4ecc-4c62-8ea8-acc5a9057f3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;DetailContainerstyle__DetailWrapper-gOTxDn fJCHkB&quot;]/div[@class=&quot;ListingDetailstyle__Detail-leUXpB davqsX&quot;]/div[@class=&quot;ListingDetailstyle__MainContainer-fckUjw dsRKkO&quot;]/div[@class=&quot;ListingDetailstyle__LeftContainerWrapper-kzCUBn dYqgCF&quot;]/div[@class=&quot;ListingDetailstyle__MainContentContainer-groYjV dMOnQB full-background&quot;]/div[@class=&quot;ListingDetailstyle__ComponentContainer-fintGE PropertySummarystyle__PropertySummaryWrapper-hLQYoo bHABqv izOVZW property-summary&quot;]/div[@class=&quot;PropertySummarystyle__AreaInfo-lijFQV gATDlP property-areas-info&quot;]/ul[1]/li[@class=&quot;PropertySummarystyle__AreaInfoItem-NjZCY dUovgc&quot;]</value>
      <webElementGuid>1d385853-ab37-4be0-8c80-b57701d07436</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[2]/div[2]/div/div/div/div[3]/ul/li</value>
      <webElementGuid>1e1beb6e-6dba-4ac5-9431-cc9439152bac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jalan Kuchai Lama, Taman Lien Hoe, Kuchai Lama, 58100, Kuala Lumpur'])[1]/following::li[1]</value>
      <webElementGuid>e8ecdd2f-a070-4f8d-a8bb-03d2ae145c17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GenKL, Kuchai Lama'])[1]/following::li[1]</value>
      <webElementGuid>0104e4aa-6d89-4635-9605-74b9983a2d6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Land area : -'])[1]/preceding::li[1]</value>
      <webElementGuid>d7f3a9bc-be75-416c-9f35-813747c7bb88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Share'])[1]/preceding::li[5]</value>
      <webElementGuid>17a794f7-5d4e-4e7d-a08f-c7685acdce60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Built-up : 1,894 sq. ft.']/parent::*</value>
      <webElementGuid>eb399c49-1009-4fd4-9247-575a28b74d02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/ul/li</value>
      <webElementGuid>6248dee1-f42b-4e74-a0f9-6052efeb3c19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Built-up : 1,894 sq. ft.' or . = 'Built-up : 1,894 sq. ft.')]</value>
      <webElementGuid>789a5906-3544-461c-9685-4e5f92076321</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
