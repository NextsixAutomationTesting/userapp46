<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Jalan Kuchai Lama, Taman Lien Hoe, Kuc_0e7f6c</name>
   <tag></tag>
   <elementGuidId>2744e57e-a630-4292-93ca-1b2da0443822</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[2]/div[2]/div/div/div/div[2]/h3/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.property-address.sale-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e7358c17-4568-453a-8ddd-7dc974444a65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>property-address sale-default</value>
      <webElementGuid>428d33df-4db5-40f3-abb7-9f19213391d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Jalan Kuchai Lama, Taman Lien Hoe, Kuchai Lama, 58100, Kuala Lumpur </value>
      <webElementGuid>350c5bb9-ee39-4b5e-9c1a-b80d26e68e9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;DetailContainerstyle__DetailWrapper-gOTxDn fJCHkB&quot;]/div[@class=&quot;ListingDetailstyle__Detail-leUXpB davqsX&quot;]/div[@class=&quot;ListingDetailstyle__MainContainer-fckUjw dsRKkO&quot;]/div[@class=&quot;ListingDetailstyle__LeftContainerWrapper-kzCUBn dYqgCF&quot;]/div[@class=&quot;ListingDetailstyle__MainContentContainer-groYjV dMOnQB full-background&quot;]/div[@class=&quot;ListingDetailstyle__ComponentContainer-fintGE PropertySummarystyle__PropertySummaryWrapper-hLQYoo bHABqv izOVZW property-summary&quot;]/div[@class=&quot;Address__Wrapper-cjOtLt fsvYLT&quot;]/h3[@class=&quot;PropertySummarystyle__H3FormatAddress-oXBHS iGXnLe format-address-wrapper&quot;]/span[@class=&quot;property-address-wrapper&quot;]/span[@class=&quot;property-address sale-default&quot;]</value>
      <webElementGuid>f367f2b8-1001-4c3a-959d-fd979c5be7f1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[2]/div[2]/div/div/div/div[2]/h3/span/span</value>
      <webElementGuid>852a1295-261e-47ae-a217-3da120c5618a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GenKL, Kuchai Lama'])[1]/following::span[2]</value>
      <webElementGuid>0a13ff05-16d8-4b71-ae57-6339b2d282bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sale RM 1,398,000'])[1]/following::span[2]</value>
      <webElementGuid>9f1e046f-5494-4e79-afc7-dca3da0953d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Built-up : 1,894 sq. ft.'])[1]/preceding::span[1]</value>
      <webElementGuid>70f36606-b4ba-41e2-b448-35db764ef52c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Land area : -'])[1]/preceding::span[1]</value>
      <webElementGuid>a52152fb-c7d3-45fe-9762-c47f16827ec8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Jalan Kuchai Lama, Taman Lien Hoe, Kuchai Lama, 58100, Kuala Lumpur']/parent::*</value>
      <webElementGuid>8f4d8739-c559-464d-a505-f38b3a9ba9c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span</value>
      <webElementGuid>2a720f43-8c20-4260-8c8f-731545e352d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Jalan Kuchai Lama, Taman Lien Hoe, Kuchai Lama, 58100, Kuala Lumpur ' or . = 'Jalan Kuchai Lama, Taman Lien Hoe, Kuchai Lama, 58100, Kuala Lumpur ')]</value>
      <webElementGuid>17989c87-d46a-4586-8273-59566ed48bff</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
