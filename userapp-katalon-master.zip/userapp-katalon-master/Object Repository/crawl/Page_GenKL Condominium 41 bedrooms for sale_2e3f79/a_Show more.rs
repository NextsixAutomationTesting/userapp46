<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Show more</name>
   <tag></tag>
   <elementGuidId>a00010f2-712b-40b3-a242-183101e452a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ShowMorestyle__ShowMoreButtonWrapper-egQzFu.hRWKpf.show-more-button > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>47053f53-980b-40ed-95d4-fbf79a7e3874</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Show more</value>
      <webElementGuid>4eab8b22-bcec-4da3-a607-090b1ef2f0b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;DetailContainerstyle__DetailWrapper-gOTxDn fJCHkB&quot;]/div[@class=&quot;ListingDetailstyle__Detail-leUXpB davqsX&quot;]/div[@class=&quot;ListingDetailstyle__MainContainer-fckUjw dsRKkO&quot;]/div[@class=&quot;ListingDetailstyle__LeftContainerWrapper-kzCUBn dYqgCF&quot;]/div[@class=&quot;ListingDetailstyle__PropertyInfo-nYNvB hfNcQw&quot;]/div[@class=&quot;ListingDetailstyle__MainContentContainer-groYjV dMOnQB&quot;]/div[@class=&quot;ListingDetailstyle__ComponentContainer-fintGE ListingDescriptionstyle__DescriptionContainer-gfGIhK bHABqv IJTWd listing-description&quot;]/div[@class=&quot;ShowMorestyle__ShowMoreContainer-jHAKYk fXRCEn&quot;]/div[@class=&quot;ShowMorestyle__ShowMoreButtonWrapper-egQzFu hRWKpf show-more-button&quot;]/a[1]</value>
      <webElementGuid>3ea15fc9-b4be-4993-b3b5-585052a1fe9c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/a</value>
      <webElementGuid>15529a9d-8124-44e4-82a2-2d512eafb17e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Show more')]</value>
      <webElementGuid>07e10806-3bbe-4bc9-b7e5-06968fef5513</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GenKL, Kuchai Lama'])[2]/following::a[1]</value>
      <webElementGuid>d9542e9d-8d9d-421f-a5b0-621ddd6a2053</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read more'])[1]/following::a[1]</value>
      <webElementGuid>cb16f981-03ab-44a5-b7f4-0c24b8671161</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Property Details'])[1]/preceding::a[1]</value>
      <webElementGuid>e8f6bf3b-b1c7-4e8a-90fd-c4b75eaa7d88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Property Type:'])[1]/preceding::a[1]</value>
      <webElementGuid>128206ce-36a2-48c6-aa58-182ce378d88d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Show more']/parent::*</value>
      <webElementGuid>96018fd0-1da8-4668-a891-8eec2db5f013</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/div/div[2]/a</value>
      <webElementGuid>1eae1843-40ee-4fc5-aa55-f63329663dcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Show more' or . = 'Show more')]</value>
      <webElementGuid>a63d72de-c68e-4b16-b9a3-b020c98b9de5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
