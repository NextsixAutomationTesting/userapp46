<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_GenKL, Kuchai LamaGEN KL  OLD KLANG ROA_a94aa4</name>
   <tag></tag>
   <elementGuidId>5f345dc5-e406-4677-bea2-791e5522e8ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>g</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ListingDetailstyle__ComponentContainer-fintGE.ListingDescriptionstyle__DescriptionContainer-gfGIhK.bHABqv.IJTWd.listing-description</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e8a88827-0ea2-480a-ae74-87d1467d9faa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-test-id</name>
      <type>Main</type>
      <value>DescriptionContainer</value>
      <webElementGuid>5009c464-5fd2-47f2-9efc-4bcd976ae83a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListingDetailstyle__ComponentContainer-fintGE ListingDescriptionstyle__DescriptionContainer-gfGIhK bHABqv IJTWd listing-description</value>
      <webElementGuid>fdea2720-71db-4225-974a-da724744eff4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GenKL, Kuchai LamaGEN KL @ OLD KLANG ROAD FOR SALE

***LOOKING FOR GENKL VALUE UNIT, FIND ME!***
ALL TYPES FACING, FLOOR, LAYOUT

Many other units for sale (From RM680psf) :
Type A 1,150sft 3 Room
Type A1 1,169sft 3 Room
Type B 1,370sft 3+2 Room
Type C 1,551sft 2 Room + 1 Studio
Type C1 1,574sft 4 Room
Type D 1,894sft 3 Room + 1 Studio

CONTACT FOR MORE DETAILS:
YOONG 016-6278258
GENKL CONDO SPECIALISTShow less</value>
      <webElementGuid>d826f537-3f56-42e4-96a4-15ddfd3c771c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;DetailContainerstyle__DetailWrapper-gOTxDn fJCHkB&quot;]/div[@class=&quot;ListingDetailstyle__Detail-leUXpB davqsX&quot;]/div[@class=&quot;ListingDetailstyle__MainContainer-fckUjw dsRKkO&quot;]/div[@class=&quot;ListingDetailstyle__LeftContainerWrapper-kzCUBn dYqgCF&quot;]/div[@class=&quot;ListingDetailstyle__PropertyInfo-nYNvB hfNcQw&quot;]/div[@class=&quot;ListingDetailstyle__MainContentContainer-groYjV dMOnQB&quot;]/div[@class=&quot;ListingDetailstyle__ComponentContainer-fintGE ListingDescriptionstyle__DescriptionContainer-gfGIhK bHABqv IJTWd listing-description&quot;]</value>
      <webElementGuid>a1d092e2-08cf-4522-b857-31ac79c66452</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[2]/div[2]/div/div[2]/div/div[2]</value>
      <webElementGuid>fd39e167-36f5-40d2-aedc-bd493370c77c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read more'])[1]/following::div[1]</value>
      <webElementGuid>da9d01e6-f877-4e8f-89a2-56cb432499d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Terms of Use'])[3]/following::div[2]</value>
      <webElementGuid>bb0a8196-a432-42f7-afde-396e474b6c2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div[2]/div/div[2]/div/div[2]</value>
      <webElementGuid>dc414b04-16ea-4bec-b3a9-293fc694157f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'GenKL, Kuchai LamaGEN KL @ OLD KLANG ROAD FOR SALE

***LOOKING FOR GENKL VALUE UNIT, FIND ME!***
ALL TYPES FACING, FLOOR, LAYOUT

Many other units for sale (From RM680psf) :
Type A 1,150sft 3 Room
Type A1 1,169sft 3 Room
Type B 1,370sft 3+2 Room
Type C 1,551sft 2 Room + 1 Studio
Type C1 1,574sft 4 Room
Type D 1,894sft 3 Room + 1 Studio

CONTACT FOR MORE DETAILS:
YOONG 016-6278258
GENKL CONDO SPECIALISTShow less' or . = 'GenKL, Kuchai LamaGEN KL @ OLD KLANG ROAD FOR SALE

***LOOKING FOR GENKL VALUE UNIT, FIND ME!***
ALL TYPES FACING, FLOOR, LAYOUT

Many other units for sale (From RM680psf) :
Type A 1,150sft 3 Room
Type A1 1,169sft 3 Room
Type B 1,370sft 3+2 Room
Type C 1,551sft 2 Room + 1 Studio
Type C1 1,574sft 4 Room
Type D 1,894sft 3 Room + 1 Studio

CONTACT FOR MORE DETAILS:
YOONG 016-6278258
GENKL CONDO SPECIALISTShow less')]</value>
      <webElementGuid>7aea7d84-542e-4bd4-bc64-5dd984bd343a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
