<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Kuchai Lama, Kuala Lumpur (1)</name>
   <tag></tag>
   <elementGuidId>74224d48-ef7c-4483-ad04-6b002618ce57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.PremiumCardstyle__AddressWrapper-ldsjqp.gRJjrp</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c9543222-2614-4a42-840a-d4bc4e9ad8fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>PremiumCardstyle__AddressWrapper-ldsjqp gRJjrp</value>
      <webElementGuid>021c1faa-27ff-4a11-a1c4-e0f6e519cdb8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kuchai Lama, Kuala Lumpur</value>
      <webElementGuid>0ee4164b-a690-4e76-9003-922f8906f607</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-104001486&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;detail-property&quot;]/div[@class=&quot;datail-title-attributes&quot;]/div[@class=&quot;PremiumCardstyle__AddressWrapper-ldsjqp gRJjrp&quot;]</value>
      <webElementGuid>9762e5fe-96df-45af-ad57-79146ebe464a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/div</value>
      <webElementGuid>ef79b40c-0be6-4560-9a0c-eca6d1d26dba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama'])[1]/following::div[1]</value>
      <webElementGuid>73ae629f-27c9-40df-ab1b-2eb1ae86c7e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM 390,000'])[1]/following::div[4]</value>
      <webElementGuid>9e20622c-7a26-4843-97c1-5b5758d5a8b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/preceding::div[3]</value>
      <webElementGuid>43565b84-118d-4dca-a7f7-41fa6921c998</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tel: +60176...'])[1]/preceding::div[4]</value>
      <webElementGuid>221befc5-477c-4cb1-8aaf-9734c8c73498</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kuchai Lama, Kuala Lumpur']/parent::*</value>
      <webElementGuid>836cec37-6bb0-4b16-93f9-4de6dedcdc66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/div/div/div[3]/div[2]/div/div</value>
      <webElementGuid>4429f9d6-681a-4f24-8978-6c3091ea44f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Kuchai Lama, Kuala Lumpur' or . = 'Kuchai Lama, Kuala Lumpur')]</value>
      <webElementGuid>7e2028ba-e6de-459c-a0f6-262dacdb8ad1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
