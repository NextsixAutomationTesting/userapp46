<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Kuchai Avenue, Kuchai Entrepreneurs Park_a27fb6 (2)</name>
   <tag></tag>
   <elementGuidId>a51c1097-bf00-42e4-9f05-dd543dc81422</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.PremiumCardstyle__TitleWrapper-cBmVrL.ePWFgo</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>c89c2565-4ade-455a-997e-1404df54dc0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>PremiumCardstyle__TitleWrapper-cBmVrL ePWFgo</value>
      <webElementGuid>d9c157b3-0bc4-4e4d-a504-2e48dd2deb32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama</value>
      <webElementGuid>9134f9d0-30c8-42da-9e49-aba4ccc45f8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-104063311&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;detail-property&quot;]/div[@class=&quot;datail-title-attributes&quot;]/h2[@class=&quot;PremiumCardstyle__TitleWrapper-cBmVrL ePWFgo&quot;]</value>
      <webElementGuid>4bc01952-6683-4312-9316-b1715cc1f65f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/h2</value>
      <webElementGuid>305bbc9a-268d-4673-a8f5-9f16bb6d695f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM 390,000'])[1]/following::h2[1]</value>
      <webElementGuid>093a33de-768c-4e17-8619-356c562881b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Daniel'])[1]/following::h2[1]</value>
      <webElementGuid>80b72ad9-47c7-4d23-801f-6f4bfa75d155</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Lama, Kuala Lumpur'])[1]/preceding::h2[1]</value>
      <webElementGuid>c3b17a54-988a-48bf-a26f-ebc698b1b0ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/preceding::h2[1]</value>
      <webElementGuid>0902eba5-fac9-4e75-b955-f34caf8badc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama']/parent::*</value>
      <webElementGuid>f981bb26-916f-478d-9b24-3d9f7a8b1e70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>f596abef-45cb-4074-b49a-10d09cbb050d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama' or . = 'Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama')]</value>
      <webElementGuid>5bf85d83-23a5-4086-8412-ef85cc83b655</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
