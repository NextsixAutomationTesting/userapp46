<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Kuchai Avenue, Kuchai Entrepreneurs Park_a27fb6</name>
   <tag></tag>
   <elementGuidId>4c46b03d-44b0-4e95-9e52-5d9324f3c5b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.PremiumCardstyle__TitleWrapper-cBmVrL.ePWFgo</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>caa6f42a-d733-4eea-b2b5-a0ee71a6d3d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>PremiumCardstyle__TitleWrapper-cBmVrL ePWFgo</value>
      <webElementGuid>d9b5872a-d0ef-4ff9-88aa-bc8cf8c76cea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama</value>
      <webElementGuid>1d1a9554-f68b-4c7a-9544-5a87833f213c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-104063311&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;detail-property&quot;]/div[@class=&quot;datail-title-attributes&quot;]/h2[@class=&quot;PremiumCardstyle__TitleWrapper-cBmVrL ePWFgo&quot;]</value>
      <webElementGuid>77af4dfe-6b54-486d-9851-bfffdc969744</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/h2</value>
      <webElementGuid>29a73f98-cd53-4ab9-8237-87b457171450</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM 390,000'])[1]/following::h2[1]</value>
      <webElementGuid>110a3f52-5a0b-43e7-899a-8b91aa9787de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Daniel'])[1]/following::h2[1]</value>
      <webElementGuid>11bb2050-971c-4d52-ab42-edd682718b33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Lama, Kuala Lumpur'])[1]/preceding::h2[1]</value>
      <webElementGuid>7498cf96-dee6-44d0-aa50-f8645220bbdd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/preceding::h2[1]</value>
      <webElementGuid>78831afa-1b61-4bf7-b08f-c3fba5e81da8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama']/parent::*</value>
      <webElementGuid>e1294078-48c0-467c-8e93-0fb70e7d832e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>4f4c3322-0b14-4f66-b800-40d049279d04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama' or . = 'Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama')]</value>
      <webElementGuid>3818d312-06c0-4128-8518-d0a796c0f5cc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
