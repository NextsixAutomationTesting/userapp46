<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Kuchai Avenue, Kuchai Entrepreneurs Park_a27fb6 (1)</name>
   <tag></tag>
   <elementGuidId>dc5864f3-af53-46af-bf58-030aa8d4d749</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.PremiumCardstyle__TitleWrapper-cBmVrL.ePWFgo</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>f885d59f-5d9c-4115-85f2-ed05e7ef1f3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>PremiumCardstyle__TitleWrapper-cBmVrL ePWFgo</value>
      <webElementGuid>56252d90-1609-4aa8-a096-138a0318a1ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama</value>
      <webElementGuid>b3f077bc-a748-4882-be9a-433e13171724</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-104063311&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;detail-property&quot;]/div[@class=&quot;datail-title-attributes&quot;]/h2[@class=&quot;PremiumCardstyle__TitleWrapper-cBmVrL ePWFgo&quot;]</value>
      <webElementGuid>12344790-ddb7-43ec-aab5-51bbde330c2f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/h2</value>
      <webElementGuid>1891d565-8f42-4d86-bfe5-e4c5fa2fd550</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM 390,000'])[1]/following::h2[1]</value>
      <webElementGuid>49038dcb-894f-4908-b32b-57a51292f34c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Daniel'])[1]/following::h2[1]</value>
      <webElementGuid>2fc7d806-15af-453c-8af2-15e5328d088a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Lama, Kuala Lumpur'])[1]/preceding::h2[1]</value>
      <webElementGuid>4293e9cb-f837-4ede-8f51-1b5358dc0163</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/preceding::h2[1]</value>
      <webElementGuid>59defcab-955d-4269-b272-ba96283a8b03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama']/parent::*</value>
      <webElementGuid>16ba2d48-2b64-4f74-b50f-09973af45074</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>daa07223-7443-4725-82bd-4ae3395bc599</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama' or . = 'Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama')]</value>
      <webElementGuid>a5c25d1f-4f24-4bdf-8285-0219ed8508a2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
