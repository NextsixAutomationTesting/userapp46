<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_RM 1,398,000</name>
   <tag></tag>
   <elementGuidId>920154f7-17ba-4569-9687-59bfce492304</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ListingPricestyle__ItemWrapper-cBCBVa.jXCKCc</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>b912225a-4d3a-420f-9832-cff06642ff73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListingPricestyle__ItemWrapper-cBCBVa jXCKCc</value>
      <webElementGuid>eee9f128-079a-4f0c-b982-c6fbdce4b9ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>RM 1,398,000</value>
      <webElementGuid>8bed1ed1-e0de-4aaf-a765-28b0f0dccf0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-100769700&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;ListingPricestyle__ListingPriceWrapper-eZrVug gUGYlt listing-price&quot;]/ul[@class=&quot;ListingPricestyle__ListWrapper-howXAt ekVrks&quot;]/li[@class=&quot;ListingPricestyle__ItemWrapper-cBCBVa jXCKCc&quot;]</value>
      <webElementGuid>441e332d-742e-44d3-81f1-a695928ec52b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div/ul/li</value>
      <webElementGuid>f1aa9054-5c4f-4439-bed4-97dd417b3621</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CF Yoong'])[1]/following::li[1]</value>
      <webElementGuid>74ff2805-a184-452c-bf8c-65b64b4dbd6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Filters'])[2]/following::li[2]</value>
      <webElementGuid>c20bdfa4-67f6-40da-9003-b0e194b61fb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GenKL, Kuchai Lama'])[1]/preceding::li[1]</value>
      <webElementGuid>e5b1303f-5e35-436a-944d-6d20e50b1a43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Lama, Kuala Lumpur'])[1]/preceding::li[1]</value>
      <webElementGuid>9bb536cc-6f22-41e8-aa08-c501c85d23bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='RM 1,398,000']/parent::*</value>
      <webElementGuid>f3e1dfca-c80f-4ec0-b826-37577d802e4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/div/div/div[3]/div/ul/li</value>
      <webElementGuid>6cb3f794-51b8-4f06-a27c-b450f625ab45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'RM 1,398,000' or . = 'RM 1,398,000')]</value>
      <webElementGuid>7cd07025-d9ea-4864-b7e0-43710a7e58e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
