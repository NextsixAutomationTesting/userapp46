<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Serviced Residence  Intermediate  Built-u_4a5b01</name>
   <tag></tag>
   <elementGuidId>3f58abd1-368e-424a-800c-e771f7b6c3df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.ListingAttributesstyle__ListingAttrsDescriptionItemWrapper-fQKuaA.fJmpgN.attributes-description-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/div[2]/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>49e74cd0-0294-4994-9b53-064111b57d21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ListingAttributesstyle__ListingAttrsDescriptionItemWrapper-fQKuaA fJmpgN attributes-description-item</value>
      <webElementGuid>004c8395-b078-452d-a914-f6b7179b2e2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Serviced Residence | Intermediate  •  Built-up : 935 sq. ft.  •  Partly furnished</value>
      <webElementGuid>11f42ebd-0f3b-440d-bfa8-a8d4953f6576</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-104063311&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;detail-property&quot;]/div[@class=&quot;datail-title-attributes&quot;]/div[@class=&quot;ListingAttributesstyle__ListingAttrsDescriptionWrapper-FnuGp ceWyz attributes-description&quot;]/p[@class=&quot;ListingAttributesstyle__ListingAttrsDescriptionItemWrapper-fQKuaA fJmpgN attributes-description-item&quot;]</value>
      <webElementGuid>db192974-676e-4221-9714-f77e7dc3c16a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/div[2]/p</value>
      <webElementGuid>743ba707-b157-4a31-ae11-c16b8653c6ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Lama, Kuala Lumpur'])[1]/following::p[1]</value>
      <webElementGuid>6118fd80-c5e2-457b-9fd8-6969c99a6ae0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama'])[1]/following::p[1]</value>
      <webElementGuid>2ab064ab-10ff-4194-9be2-ecc8abedb597</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/preceding::p[1]</value>
      <webElementGuid>e68c6db7-3dad-4ce4-9f41-09cf36c11fa2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tel: +60123...'])[1]/preceding::p[1]</value>
      <webElementGuid>1f59ae92-8d92-4e7b-a771-a406afbc9393</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Serviced Residence | Intermediate  •  Built-up : 935 sq. ft.  •  Partly furnished']/parent::*</value>
      <webElementGuid>ef9ffa9a-c6d0-4b86-b722-2ae264246108</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/p</value>
      <webElementGuid>1c62553d-add3-4e94-8f3e-18334500eaff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Serviced Residence | Intermediate  •  Built-up : 935 sq. ft.  •  Partly furnished' or . = 'Serviced Residence | Intermediate  •  Built-up : 935 sq. ft.  •  Partly furnished')]</value>
      <webElementGuid>3a6e4d7a-ef8b-4a4b-8cf8-0e732c503534</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
