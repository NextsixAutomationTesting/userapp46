<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Kuchai Lama, Kuala Lumpur</name>
   <tag></tag>
   <elementGuidId>daa86303-99c6-4d59-9c23-1f722068d988</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.PremiumCardstyle__AddressWrapper-ldsjqp.gRJjrp</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ff3cd0e4-a248-44bb-86fb-98b172181e11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>PremiumCardstyle__AddressWrapper-ldsjqp gRJjrp</value>
      <webElementGuid>4ef6dd58-5d93-4d8f-bf42-953269058bfb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kuchai Lama, Kuala Lumpur</value>
      <webElementGuid>ee3679c4-c2be-475f-a8e4-b49c671dce8e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;ListingsListstyle__ListingResultPage-ebBfds bxqVwU&quot;]/div[@class=&quot;ListingsListstyle__ResultsContainer-iWlzlp fjhOsm&quot;]/ul[@class=&quot;ListingsListstyle__ListingsListContainer-gFQClw hrxUtk listing-list&quot;]/li[@class=&quot;ListingsListstyle__ListingListItemWrapper-bmHwPm lfznXs sale-104063311&quot;]/div[1]/div[@class=&quot;PremiumCardstyle__CardWrapper-cvkMVX jRRXhG&quot;]/div[@class=&quot;PremiumCardstyle__DescriptionWrapper-fIqxyF bgYgqk Premium&quot;]/div[@class=&quot;detail-property&quot;]/div[@class=&quot;datail-title-attributes&quot;]/div[@class=&quot;PremiumCardstyle__AddressWrapper-ldsjqp gRJjrp&quot;]</value>
      <webElementGuid>eccc5281-39a7-450d-86a7-91a04692afde</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div[3]/div/ul/li/div/div/div[3]/div[2]/div/div</value>
      <webElementGuid>50932c6d-2f22-43fa-b4e3-51b71ee8b42c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kuchai Avenue, Kuchai Entrepreneurs Park, Kuchai Lama'])[1]/following::div[1]</value>
      <webElementGuid>656bf5a4-a59f-4efc-b10d-af43888e115e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RM 390,000'])[1]/following::div[4]</value>
      <webElementGuid>a3ad979c-6fb7-4441-84f7-475e6d32f782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/preceding::div[3]</value>
      <webElementGuid>796ea604-c283-4eaa-8b50-226adef8e30c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tel: +60123...'])[1]/preceding::div[4]</value>
      <webElementGuid>543f793d-e209-45e0-a878-f1613b63a781</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kuchai Lama, Kuala Lumpur']/parent::*</value>
      <webElementGuid>ecddc37a-947e-4894-b846-8259e825106d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/div/div/div[3]/div[2]/div/div</value>
      <webElementGuid>0bb742b3-ff5f-4f55-8fff-ca74ec825f4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Kuchai Lama, Kuala Lumpur' or . = 'Kuchai Lama, Kuala Lumpur')]</value>
      <webElementGuid>619d40ed-4f25-451a-9265-75b9f464c594</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
