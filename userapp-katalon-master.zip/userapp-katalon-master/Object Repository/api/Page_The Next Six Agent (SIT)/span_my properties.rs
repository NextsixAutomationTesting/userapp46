<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_my properties</name>
   <tag></tag>
   <elementGuidId>f8b94b78-0d5b-441f-b200-546bf6851513</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='navItem-my properties-4']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fbb83a59-b339-4963-abd9-bc04a7edd429</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>my properties</value>
      <webElementGuid>654e79a9-f2aa-4460-a896-8dd8486e46f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navItem-my properties-4&quot;)/span[1]</value>
      <webElementGuid>610b9a4b-2c4b-4cda-8d38-4a7f592962a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='navItem-my properties-4']/span</value>
      <webElementGuid>206e579e-4f52-46f4-8ea9-a44d60e7f82b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='my e-business card'])[1]/following::span[1]</value>
      <webElementGuid>66640fca-fa67-47f5-9e5b-6bcb818082eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='my profile'])[1]/following::span[2]</value>
      <webElementGuid>1283e406-9ffa-499e-8257-ab6cfa0ca77d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='my auctions'])[1]/preceding::span[1]</value>
      <webElementGuid>b25aeb27-d0e7-419d-886b-22aa8486aa46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='my challenges'])[1]/preceding::span[2]</value>
      <webElementGuid>cbb42ae8-f815-44e2-91d7-91dec3dc7793</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='my properties']/parent::*</value>
      <webElementGuid>8b844857-0a73-4ef0-a084-a410927b9db7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a/span</value>
      <webElementGuid>cab4676d-bd62-4013-a04e-e7e341d019f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'my properties' or . = 'my properties')]</value>
      <webElementGuid>5621b289-91b1-451a-a3a7-ff63ce36acee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
