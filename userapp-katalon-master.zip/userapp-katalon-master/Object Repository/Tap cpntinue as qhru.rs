<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>Tap cpntinue as qhru</name>
   <tag></tag>
   <elementGuidId>13c1e504-9058-49b6-98cd-7b46391da384</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Continue as Qhru</value>
      <webElementGuid>d524a411-bab3-43f7-84a3-531e403861a4</webElementGuid>
   </webElementProperties>
   <locator>//*[(@text = 'Continue as Qhru' or . = 'Continue as Qhru')]</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
